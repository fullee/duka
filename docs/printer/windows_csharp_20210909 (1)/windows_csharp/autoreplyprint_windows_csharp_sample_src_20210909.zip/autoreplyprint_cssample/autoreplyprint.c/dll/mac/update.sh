#!/bin/sh
cp ../../../autoreplyprint_src/autoreplyprint_main/autoreplyprint.h .
cp ../../build-autoreplyprint-Desktop_Qt_5_12_0_clang_64bit-Release/libautoreplyprint*.dylib .

