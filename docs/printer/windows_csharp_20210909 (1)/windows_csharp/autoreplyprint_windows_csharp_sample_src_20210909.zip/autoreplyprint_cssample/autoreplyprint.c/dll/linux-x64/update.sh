#!/bin/sh
cp ../../../autoreplyprint_src/autoreplyprint_main/autoreplyprint.h .
cp ../../build-autoreplyprint-Qt_5_6_3_x64_static-Release/libautoreplyprint.so* .

