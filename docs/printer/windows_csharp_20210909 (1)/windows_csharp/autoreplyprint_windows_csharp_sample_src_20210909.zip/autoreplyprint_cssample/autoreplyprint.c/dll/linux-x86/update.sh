#!/bin/sh
cp ../../../autoreplyprint_src/autoreplyprint_main/autoreplyprint.h .
cp ../../build-autoreplyprint-Qt_5_6_3_x86_static-Release/libautoreplyprint.so* .

