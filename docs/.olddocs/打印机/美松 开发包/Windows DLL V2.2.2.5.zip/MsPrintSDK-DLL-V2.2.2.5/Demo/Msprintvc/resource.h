//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Msqrdemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MSQRDEMO_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_GETQRCODE                   1000
#define IDC_EDIT1                       1001
#define IDC_EDIT2                       1002
#define IDC_EDIT3                       1003
#define IDC_EDIT4                       1004
#define IDC_EDIT5                       1005
#define IDC_BUTTON1                     1006
#define IDC_EDIT_PRINTSTRING            1007
#define IDC_BUTTON30                    1007
#define IDC_BUTTON2                     1008
#define IDC_EDIT6                       1009
#define IDC_EDIT7                       1010
#define IDC_EDIT8                       1011
#define IDC_EDIT9                       1012
#define IDC_EDIT10                      1013
#define IDC_EDIT11                      1014
#define IDC_EDIT12                      1015
#define IDC_EDIT13                      1016
#define IDC_EDIT14                      1017
#define IDC_EDIT15                      1018
#define IDC_EDIT16                      1019
#define IDC_EDIT17                      1020
#define IDC_EDIT18                      1021
#define IDC_EDIT19                      1022
#define IDC_EDIT20                      1023
#define IDC_EDIT21                      1024
#define IDC_EDIT22                      1025
#define IDC_EDIT23                      1026
#define IDC_EDIT24                      1027
#define IDC_EDIT25                      1028
#define IDC_BUTTON3                     1029
#define IDC_BUTTON4                     1030
#define IDC_BUTTON5                     1031
#define IDC_BUTTON6                     1032
#define IDC_BUTTON7                     1033
#define IDC_BUTTON8                     1034
#define IDC_BUTTON9                     1035
#define IDC_BUTTON10                    1036
#define IDC_BUTTON11                    1037
#define IDC_BUTTON12                    1038
#define IDC_EDIT26                      1039
#define IDC_EDIT27                      1040
#define IDC_BUTTON13                    1041
#define IDC_BUTTON14                    1042
#define IDC_BUTTON15                    1043
#define IDC_BUTTON16                    1044
#define IDC_BUTTON17                    1045
#define IDC_BUTTON18                    1046
#define IDC_BUTTON19                    1047
#define IDC_BUTTON20                    1048
#define IDC_BUTTON21                    1049
#define IDC_BUTTON22                    1050
#define IDC_GETQRCODE2                  1051
#define IDC_GETQRCODE3                  1052
#define IDC_GETQRCODE4                  1053
#define IDC_GETQRCODE5                  1054
#define IDC_EDIT28                      1055
#define IDC_EDIT29                      1056
#define IDC_EDIT30                      1057
#define IDC_EDIT31                      1058
#define IDC_COMBO_NV                    1059
#define IDC_BUTTON23                    1060
#define IDC_BUTTON24                    1061
#define IDC_BUTTON25                    1062
#define IDC_BUTTON26                    1063
#define IDC_BUTTON27                    1064
#define IDC_BUTTON28                    1065
#define IDC_EDIT_PRINTSTRING2           1066
#define IDC_BUTTON31                    1066
#define IDC_COMBO_NV2                   1067
#define IDC_COMBO_BAUDRATE              1067
#define IDC_BUTTON29                    1068
#define IDC_COMBO_CONNWAY               1069
#define IDC_COMBO_PRINTMODEL            1072

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1069
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
