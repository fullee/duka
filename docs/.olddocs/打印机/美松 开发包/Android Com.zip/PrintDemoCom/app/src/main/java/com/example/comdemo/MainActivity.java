package com.example.comdemo;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import com.msprintsdk.JNACom;

import com.msprintsdk.PrintCmd;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.DocumentsContract;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;


import static android.content.ContentValues.TAG;
import static com.example.comdemo.GetPathFromUri.getStoragePath;
import static com.msprintsdk.PrintCmd.PrintFeedDot;
import static com.msprintsdk.UtilsTools.PrintBase64;
import static com.msprintsdk.UtilsTools.ReadTxtFile;
import static com.msprintsdk.UtilsTools.data;
import static com.msprintsdk.UtilsTools.getExtensionName;
import static com.msprintsdk.UtilsTools.hexToByteArr;
import static com.msprintsdk.UtilsTools.isHexStrValid;
import static com.msprintsdk.UtilsTools.unicodeToUtf8;


@SuppressLint("SimpleDateFormat")
public class MainActivity extends Activity {
    SerialPortFinder mSerialPortFinder;//串口设备搜索
    Spinner mSpinnerCOMA;
    Spinner mSpinnerBaudRateCOMA;
    public static Spinner spinnerpaired;
    public static Spinner spinnerstutas;
    public static Button mbtn_receiptPrint,mbtn_imgPrint,mbtn_CyclesPrint,mbtn_findFile,mbtn_printContent;
    public static Button mbtn_getStatus;
    public static EditText m_edtImage;
    public static EditText m_edtTextCycles;
    public static EditText edtText5;
    public static CheckBox btn_hex;
    public static CheckBox checkBox;
    static int printnum = 0;
    private SerialPort mSerialPort;
    private String sPort="/dev/";
    private int iBaudRate=115200;
    public static EditText m_edtTextList;
    SimpleDateFormat m_sdfDate = new SimpleDateFormat("HH:mm:ss ");
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"); // 国际化标志时间格式类
    static final String[] m_nStr_001 = {"PrintFeedline", "PrintSelfcheck","Example01" };
    static final String[] m_nStr_002 = {"GetStatus"};
    static final int FILE_SELECT_CODE = 0;
    static final int FILE_SELECT_TXT = 1;
    public static AlertDialog alertDialog1;
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE, Environment.DIRECTORY_DOWNLOADS,
            Environment.getExternalStorageDirectory().getAbsolutePath()};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setControls();
        getSPData();
        alertDialog1 = new AlertDialog.Builder(MainActivity.this)
                .setTitle("Continuous print")//标题
                .setIcon(R.mipmap.ic_launcher)//图标
                .setNeutralButton("Stop", new DialogInterface.OnClickListener() {//添加普通按钮
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        printnum=0;
                        handler.removeCallbacks(runnable);
                        mbtn_receiptPrint.setEnabled(true);
                        mbtn_imgPrint.setEnabled(true);
                        mbtn_CyclesPrint.setEnabled(true);
                        mbtn_findFile.setEnabled(true);
                        mbtn_printContent.setEnabled(true);

                    }
                }).create();
        alertDialog1.setCanceledOnTouchOutside(false);
    }

    private void setControls()
    {
        try{
            mSpinnerCOMA=(Spinner)findViewById(R.id.SpinnerCOMA);
            mSpinnerBaudRateCOMA=(Spinner)findViewById(R.id.SpinnerBaudRateCOMA);
            spinnerpaired = (Spinner) findViewById(R.id.spinner_001);
            ArrayAdapter<String> adapter001 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, m_nStr_001);
            adapter001.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerpaired.setAdapter(adapter001);

            spinnerstutas = (Spinner) findViewById(R.id.spinner_002);
            ArrayAdapter<String> adapter002 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, m_nStr_002);
            adapter002.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerstutas.setAdapter(adapter002);

            m_edtTextList = (EditText) findViewById(R.id.editText2);
            m_edtTextList.setText("");

            m_edtImage = (EditText) findViewById(R.id.editText3);
            m_edtImage.setText("");
            m_edtImage.setOnClickListener(new ButtonClickEvent());
            m_edtImage.setInputType(InputType.TYPE_NULL);

            m_edtTextCycles = (EditText) findViewById(R.id.editText4);

            edtText5 = (EditText) findViewById(R.id.editText5);
            edtText5.setText("");

            mbtn_receiptPrint = (Button) findViewById(R.id.btn_Print1);
            mbtn_receiptPrint.setOnClickListener(new PrintClickListener());

            mbtn_imgPrint = (Button) findViewById(R.id.btn_Print2);
            mbtn_imgPrint.setOnClickListener(new PrintClickListener());

            mbtn_CyclesPrint = (Button) findViewById(R.id.btn_Print4);
            mbtn_CyclesPrint.setOnClickListener(new PrintClickListener());

            mbtn_findFile = (Button) findViewById(R.id.btn_Print5);
            mbtn_findFile.setOnClickListener(new PrintClickListener());

            mbtn_printContent = (Button) findViewById(R.id.btn_Print6);
            mbtn_printContent.setOnClickListener(new PrintClickListener());

            mbtn_getStatus = (Button) findViewById(R.id.btn_GetStatus);
            mbtn_getStatus.setOnClickListener(new GetClickListener());

            btn_hex = (CheckBox) findViewById(R.id.checkHex);
            btn_hex.setOnClickListener(new PrintClickListener());

            checkBox = (CheckBox) findViewById(R.id.checkCut);
            checkBox.setOnClickListener(new PrintClickListener());

            mSerialPortFinder= new SerialPortFinder();
            //JNACom.INSTANCE.SetDevname(1,"",0);
            String[] entryValues = mSerialPortFinder.getAllDevicesPath();
            List<String> allDevices = new ArrayList<String>();
            for (int i = 0; i < entryValues.length; i++) {
                try {
                    mSerialPort =  new SerialPort(new File(entryValues[i]), iBaudRate, 0);
                    allDevices.add(entryValues[i]);

                }catch (Exception e){
                    e.fillInStackTrace();
                }
            //    JNACom.INSTANCE.SetClose();

            }
            ArrayAdapter<String> aspnDevices = new ArrayAdapter<String>(this,
                    android.R.layout.simple_spinner_item, allDevices);
            aspnDevices.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            mSpinnerCOMA.setAdapter(aspnDevices);
            if (allDevices.size()>1)
            {

                mSpinnerCOMA.setSelection(0);
            }
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.baudrates_value,android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            mSpinnerBaudRateCOMA.setAdapter(adapter);
            mSpinnerBaudRateCOMA.setSelection(4);
        }
        catch(Exception e)
        {
            Log.d("MainActivity","setControls:"+e.getMessage());
        }
    }

    // handler对象，接收消息
    public  Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            // 处理从子线程发送过来的消息
            int arg1 = msg.arg1;  //获取消息携带的属性值
            int arg2 = msg.arg2;
            int what = msg.what;
            Object result = msg.obj;

            switch(what)
            {
                case 0:
                    break;
                case 3:
                    try {
                        Thread.sleep(300);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                case 4:
                    ShowMessage(result.toString());
                    break;
                default:
                    break;
            }
        }
    };

    //------------------------------------------显示消息
    private void ShowMessage(String sMsg) {
        StringBuilder sbMsg = new StringBuilder();
        sbMsg.append(m_edtTextList.getText());
        sbMsg.append(m_sdfDate.format(new Date()));
        sbMsg.append(sMsg);
        sbMsg.append("\r\n");
        m_edtTextList.setText(sbMsg);
        m_edtTextList.setSelection(sbMsg.length(), sbMsg.length());
    }


    //----------------------选择文件------------------------------
    class ButtonClickEvent implements View.OnClickListener {
        public void onClick(View view) {
            try {
                switch (view.getId()) {
                    case R.id.editText3:
                        showFileChooser();
                        break;
                    default:
                        break;
                }
            } catch (Exception e) {
                Log.e(TAG, "CheckClickListener:" + e.getMessage());
            }
        }
    }


    //显示记录并走纸
    public void ShowPrintClick(String strValue) {
        try {
            if (strValue.equals("PrintFeedline")) {
                strValue = PrintCmd.JNAByteToString(PrintCmd.SetReadZKmode(0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                strValue = "e6a281e99c9ee68891e5969ce6aca2e4bda00a";
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString("中华人民共和国abcdefg123456", 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintFeedline(2));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                strValue = PrintCmd.JNAByteToString(PrintFeedDot(100));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                strValue = PrintCmd.JNAByteToString(PrintCmd.SetClean());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
            } else if (strValue.equals("PrintSelfcheck")) {
                String tValue = PrintCmd.JNAByteToString(PrintCmd.PrintSelfcheck());
                JNACom.INSTANCE.PrintTransmitJNA(tValue, tValue.length());
            } else if (strValue.equals("Example01")) {
                byte[] bSendData;
                String strdata = "1D 76 30 00 30 00 5D 00 00 00 00 00 00 00 00 00 00 00 03 FF C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 3F FF F8 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 FF FF FF 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 FF FF FF 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 FF FF FF 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 1F FF FF FF C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF FF FF FF E0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 03 F0 00 0F FF F0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 06 00 00 03 FF FE 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 06 00 00 03 FF FE 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 08 00 00 00 FF FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 08 00 00 00 FF FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 70 00 00 00 3F FF 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 01 00 00 00 00 1F FF 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 0F FF 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 FF C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 FF C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 FF C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 FF C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF F0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 7F FF FF 80 00 01 FE 00 00 00 00 3F C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 7F FF FF 80 00 01 FE 00 00 00 00 3F C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 7F FF FF 80 00 03 FE 00 00 00 00 3F C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 7F FF FF 80 00 03 FE 00 00 00 00 7F C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 7F FF FF 80 00 03 FE 00 00 00 00 7F C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 7F FF FF 80 00 03 FC 00 00 00 00 7F C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF C0 00 00 00 00 00 00 00 00 00 7F 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF C0 00 00 00 00 00 00 00 00 00 7F 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF C0 00 00 00 00 00 00 00 00 00 7F 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF C0 00 00 00 0F FC 00 FF F8 0F FF FC 07 FF F0 0F F0 7F C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF C0 00 00 00 0F FC 00 FF F8 0F FF FC 07 FF F0 0F F0 7F C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF 00 00 00 00 0F FC 07 FF FF 0F FF FC 3F FF F8 0F F3 FF E0 00 00 00 00 00 00 00 00 00 00 00 00 C0 00 00 30 C0 00 00 00 00 00 00 18 00 00 00 00 FF 00 00 00 00 0F F8 1F FF FF 1F FF FC FF FF FC 0F FF FF F0 00 00 00 30 00 30 00 00 00 00 00 00 E0 00 00 30 C0 00 00 33 06 00 00 1C 00 00 00 03 FF FF FE 03 C0 0F F8 1F F3 FF C0 FF 81 FF 8F FC 1F FF FF F0 00 00 00 30 07 F8 00 00 00 00 00 00 E0 00 00 71 C0 00 06 3B 1F 00 00 38 00 00 00 03 FF FF FE 03 C0 0F F8 FF C0 7F C0 FF 01 FF 03 FE 1F F0 3F F0 00 00 00 1F FC 30 00 01 80 00 00 60 E0 00 00 71 80 00 07 F3 F6 00 00 30 60 00 00 03 FF FF FE 03 C0 0F F8 FF C0 7F C0 FF 01 FF 03 FE 1F F0 3F F0 00 00 00 1C 30 30 00 01 80 00 00 30 C0 00 00 E1 80 C0 06 33 06 00 00 67 F0 00 00 03 FF FF FE 03 C0 0F F8 FF C0 7F C0 FF 01 FF 03 FE 1F F0 3F F0 00 00 00 18 30 30 00 00 C0 00 00 1C C0 00 00 C3 1F C0 06 33 06 00 00 FC E0 00 00 03 FF FF F0 0F C0 3F F9 FF C0 7F C0 FF 03 FC 03 FE 1F E0 3F F0 00 00 00 18 30 30 00 00 E0 00 00 1C C0 00 01 C7 F1 80 06 33 0C 00 01 C1 C0 00 00 03 FF FF F0 0F C0 3F F9 FF C1 FF C7 FF 03 FC 03 FE 1F E0 3F E0 00 00 00 18 30 30 00 00 60 00 00 0C C0 00 03 C6 33 00 06 33 6C 00 03 F3 80 00 00 03 FF 00 00 00 00 3F F1 FF FF FF C7 FF 0F FC 03 FE 1F E0 7F E0 00 00 00 18 37 B0 00 00 71 80 00 01 C0 00 07 CC 33 00 06 F3 3C 00 07 1F 00 00 00 0F FE 00 00 00 00 3F F1 FF FF FF C7 FF 0F FC 03 FC 1F E0 7F E0 00 00 00 1B FE 30 00 00 70 C0 00 01 80 C0 06 DB 30 00 07 F3 1C 00 0E 0E 00 00 00 0F FE 00 00 00 00 3F F3 FF 00 00 07 FE 0F F8 03 FC FF E0 7F E0 00 00 00 18 30 30 00 C0 00 60 00 01 9F C0 0C C3 BC 00 06 33 00 00 18 1F 80 00 00 0F FE 00 00 00 00 3F F3 FF 00 00 07 FE 0F F8 03 FC FF E0 7F E0 00 00 00 18 30 30 00 C0 00 38 00 3F F1 C0 18 C7 37 00 06 33 0F 00 00 39 C0 00 00 0F FE 00 00 00 00 3F F3 FF 00 00 07 FE 0F F8 03 FC FF E0 7F E0 00 00 00 18 30 30 00 D8 00 3C 01 F3 81 80 00 CE 33 80 06 33 FE 00 00 F8 F0 00 00 0F FE 00 00 00 00 7F F3 FF 00 00 07 FE 0F F8 03 FC FF C0 7F C0 00 00 00 18 31 B0 01 D8 00 1C 00 03 01 80 00 D8 31 C0 06 F3 06 00 01 DC 3C 00 00 0F FE 00 00 00 00 7F F3 FF 01 FF 0F FE 0F F8 0F F8 FF C0 7F C0 00 00 00 18 7F B0 01 D8 00 0C 00 03 01 80 00 F1 B0 C0 07 B3 C6 00 07 1C 1F 00 00 0F F8 00 00 00 00 7F 83 FF 03 FC 0F FE 0F F8 3F F8 FF C0 7F C0 00 00 00 1F F0 30 01 9C 00 00 00 07 01 80 01 C0 F0 00 0C 33 6C 00 1C 18 7F F0 00 1F FF FF E0 00 00 7F 81 FF DF FC 0F FF 0F FF 7F F1 FF C1 FF C0 00 00 00 30 30 30 01 8C 00 00 00 06 E1 80 00 C0 70 00 0C 33 6C 00 70 1F F3 00 00 1F FF FF E0 00 00 7F 81 FF FF F8 0F FF 83 FF FF 81 FF C1 FF C0 00 00 00 30 30 30 03 8C 03 00 00 06 73 80 00 06 3C 00 0C 33 3C 00 C7 F8 60 00 00 1F FF FF E0 00 00 7F 81 FF FF F8 0F FF 83 FF FF 81 FF C1 FF C0 00 00 00 30 30 30 07 86 03 00 00 0C 33 00 03 03 87 00 0C 33 18 00 00 38 60 00 00 1F FF FF E0 00 00 7F 81 FF FF F8 0F FF 83 FF FF 81 FF C1 FF C0 00 00 00 30 30 30 03 06 03 00 00 1C 33 00 03 61 C3 C0 0C 33 18 00 00 30 60 00 00 1F FF FF E0 00 00 FF 80 FF FF F0 0F FF 01 FF FF 01 FF 01 FF 00 00 00 00 60 30 30 03 03 01 80 00 18 03 00 03 60 C0 E0 18 33 3C 00 00 70 60 00 00 1F FF FF E0 00 00 FF 80 0F FE 00 07 FF 00 FF FC 01 FF 01 FF 00 00 00 00 60 30 30 00 03 81 80 00 30 03 00 07 30 00 60 18 33 7E 00 00 60 E0 00 00 00 00 00 00 00 00 FF 00 00 00 00 00 00 00 00 00 01 00 00 00 00 00 00 00 E0 30 30 00 01 E1 80 00 71 87 00 07 18 00 00 18 33 67 00 00 E0 C0 00 00 00 00 00 00 00 00 FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 C0 31 B0 00 00 79 C0 00 E0 C6 00 0E 0C 0C 00 31 B3 C3 C0 01 D8 C0 00 00 00 00 00 00 00 00 FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 01 80 30 F0 00 00 0F C0 01 C0 76 00 0E 07 0C 00 30 F3 C3 F0 03 8E C0 00 00 00 00 00 00 00 03 FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 03 00 30 70 00 00 00 00 03 80 3E 00 00 01 CE 00 60 73 80 00 06 07 C0 00 00 00 00 00 00 00 03 FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 30 00 00 00 00 06 00 1C 00 00 00 7E 00 00 33 00 00 0C 03 80 00 00 00 00 00 00 00 1F FE 00 00 00 00 1F F0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 1C 00 0C 00 00 00 00 00 00 00 00 00 38 01 80 00 00 00 00 00 00 00 1F FE 00 00 00 00 3F E0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 1F FC 00 00 00 00 FF E0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 1F FC 00 00 00 00 FF E0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 03 FF 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 03 FF 80 00 00 00 01 02 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 FF 80 00 21 E0 01 83 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 02 00 00 00 00 00 0F FF 00 00 3E 40 01 02 00 00 1E 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 02 00 00 00 00 00 0F FF 00 00 27 80 01 02 60 21 E4 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 3F F8 00 00 78 80 02 3F 80 10 48 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 01 00 00 00 00 00 7F F0 00 00 40 80 02 44 00 10 30 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 01 C0 00 00 00 01 FF E0 00 00 4F 80 1F 87 80 02 3E 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 01 C0 00 00 00 01 FF E0 00 00 F8 00 24 79 00 03 C2 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 C0 00 00 00 03 FF C0 00 00 A0 00 04 09 E0 12 44 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 E0 00 00 00 0F FF 00 00 00 47 E0 06 FF 03 E3 F4 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 E0 00 00 00 0F FF 00 00 00 FA 40 19 12 00 44 88 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 38 00 00 00 3F FC 00 00 03 24 80 68 1E 00 44 88 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 1F 00 00 03 FF F8 00 00 04 48 81 8B F0 00 47 E8 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 80 00 0F FF F0 00 00 18 91 00 11 20 00 49 10 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 80 00 0F FF F0 00 00 23 22 00 11 3C 00 89 10 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 03 FC 03 FF FF 80 00 00 04 42 00 12 20 00 9A A0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 03 FC 03 FF FF 80 00 00 18 84 00 23 C0 0F D2 60 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF FF FF FC 00 00 00 23 28 01 24 60 00 38 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 7F FF FF F0 00 00 00 0C 30 00 C8 18 00 07 8C 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 0F FF FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF E0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF E0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF E0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 ";
                bSendData = hexStringToBytes(strdata);

                int iDataLen = bSendData.length;
                int iValue = 0 ;
                int iIndex;
                int iSendLen = 0;
                for (iIndex=0;iIndex<iDataLen;iIndex=iIndex+1024)
                {
                    if(iIndex + 1024> iDataLen)
                    {
                        iSendLen = iDataLen  - iIndex;
                    }
                    else
                    {
                        iSendLen = 1024;
                    }
                    String byteValue = PrintCmd.JNAByteToString(bSendData,iIndex,iIndex+iSendLen);
                    iValue = JNACom.INSTANCE.PrintTransmitJNA(byteValue,byteValue.length());
                    try {
                        Thread.sleep(20); //2019/11/05由144调整为256，解决打印5K数据问题
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    //USB口使用
                    //usleep(1000*20);
                }
                strValue = PrintCmd.JNAByteToString(PrintCmd.SetReadZKmode(0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                strValue = PrintCmd.JNAByteToString(PrintFeedDot(100));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                StringBuilder m_sbData;
                m_sbData = new StringBuilder("店号：8888          机号：100001");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                m_sbData = new StringBuilder("电话:0755-12345678");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                m_sbData = new StringBuilder("收银：01-店长");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("时间：" + data());
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("-------------------------------");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                byte[] bByte = new byte[3];
                bByte[0] = 12;
                bByte[1] = 18;
                bByte[2] = 26;
                strValue = PrintCmd.JNAByteToString(PrintCmd.SetHTseat(bByte, 3));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("代码");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 1));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                m_sbData = new StringBuilder("单价");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 1));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                m_sbData = new StringBuilder("数量");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 1));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                m_sbData = new StringBuilder("金额");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                m_sbData = new StringBuilder("48572819");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 1));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("2.00");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 1));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("3.00");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 1));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("6.00");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("怡宝矿泉水");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("48572820");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 1));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("2.50");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 1));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("2.00");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 1));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("5.00");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("百事可乐(罐装)");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("-------------------------------");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("合计：");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 1));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("5.00");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 1));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("11.00");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                m_sbData = new StringBuilder("优惠：");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 1));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder(" 0.00");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                m_sbData = new StringBuilder("应付：");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 1));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("11.00");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                m_sbData = new StringBuilder("微信支付：");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 1));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("11.00");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                m_sbData = new StringBuilder("找零：");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 1));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintNextHT());
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder(" 0.00");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());

                m_sbData = new StringBuilder("-------------------------------");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("会员：");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("券号：");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("-------------------------------");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                PrintFeedDot(20);
                m_sbData = new StringBuilder("手机易捷通：ejeton.com.cn ");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("客户热线：400-6088-160");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("微信号：ejeton ");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintString(m_sbData.toString(), 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                m_sbData = new StringBuilder("http://weixin.qq.com/r/R3VZQQDEi130rUQi9yBV");
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintFeedline(2));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintQrcode(unicodeToUtf8(m_sbData.toString()), 10, 5, 0));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintFeedline(5));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
                strValue = PrintCmd.JNAByteToString(PrintCmd.PrintCutpaper(1));
                JNACom.INSTANCE.PrintTransmitJNA(strValue, strValue.length());
            }
        }catch (Exception e){
            e.fillInStackTrace();
        }
    }

    private int PrintStatus() {
        int iResult = 1;
        int iValue = -1;
        byte[] bRead1 = new byte[1];
        String strValue = "";
        String Status ="";
        Status = PrintCmd.JNAByteToString(PrintCmd.GetStatus1());
        if(!Status.equals("")){
            bRead1 = hexStringToBytes(JNACom.INSTANCE.GetTransmitJNA(Status,Status.length()));
            iValue = PrintCmd.CheckStatus1(bRead1[0]);
            if(iValue !=0){
                strValue = PrintCmd.getStatusDescriptionEn(iValue);
                ShowMessage(strValue);
            }
        }
        if(iValue ==0){
            iValue = -1;
            Status = PrintCmd.JNAByteToString(PrintCmd.GetStatus2());
            if(!Status.equals("")){
                bRead1 = hexStringToBytes(JNACom.INSTANCE.GetTransmitJNA(Status,Status.length()));
                iValue = PrintCmd.CheckStatus2(bRead1[0]);
                if(iValue !=0){
                    strValue = PrintCmd.getStatusDescriptionEn(iValue);
                    ShowMessage(strValue);
                }
            }
        }
        if(iValue ==0){
            iValue = -1;
            Status = PrintCmd.JNAByteToString(PrintCmd.GetStatus3());
            if(!Status.equals("")){
                bRead1 = hexStringToBytes(JNACom.INSTANCE.GetTransmitJNA(Status,Status.length()));
                iValue = PrintCmd.CheckStatus3(bRead1[0]);
                if(iValue !=0){
                    strValue = PrintCmd.getStatusDescriptionEn(iValue);
                    ShowMessage(strValue);
                }
            }
        }
        if(iValue ==0){
            iValue = -1;
            Status = PrintCmd.JNAByteToString(PrintCmd.GetStatus4());
            if(!Status.equals("")){
                bRead1 = hexStringToBytes(JNACom.INSTANCE.GetTransmitJNA(Status,Status.length()));
                iValue = PrintCmd.CheckStatus4(bRead1[0]);
                if(iValue !=0){
                    strValue = PrintCmd.getStatusDescriptionEn(iValue);
                    ShowMessage(strValue);
                }
            }
        }
        if(iValue==0) {
            strValue = PrintCmd.getStatusDescriptionEn(iValue);
            ShowMessage(strValue);
        }
        iResult = iValue;
        return iResult;
    }

    /**
     * 打印机状态查询
     */
    class GetClickListener implements View.OnClickListener {

        @Override
        public void onClick(View view) {
            try {
                switch (view.getId()) {
                    case R.id.btn_GetStatus:
                        String Value = spinnerstutas.getSelectedItem().toString();

                        int iDriverCheck ;
                        try {
                            String cDevname = mSpinnerCOMA.getSelectedItem().toString();
                            int iBaudrate = Integer.valueOf(mSpinnerBaudRateCOMA.getSelectedItem().toString());
                            JNACom.INSTANCE.SetDevname(1,cDevname,iBaudrate);
                            iDriverCheck = JNACom.INSTANCE.SetInit();

                        }catch (Exception e){
                            iDriverCheck = -1;
                        }

                        if (iDriverCheck == 1) {
                            ShowMessage("Failed to open serial port:No serial read/write permission!");
                            return;
                        }else
                            if (Value.equals("GetStatus")) {
                                 PrintStatus();
                            }
                        break;
                    default:
                        break;
                }
            } catch (Exception e) {
                ShowMessage(e.getMessage());
                Log.e(TAG, "GetClickListener:" + e.getMessage());
            }
        }
    }

    class PrintClickListener implements View.OnClickListener {

        @Override
        public void onClick(View view) {
            try {
                int iDriverCheck ;
                try {
                    String cDevname = mSpinnerCOMA.getSelectedItem().toString();
                    int iBaudrate = Integer.valueOf(mSpinnerBaudRateCOMA.getSelectedItem().toString());
                    JNACom.INSTANCE.SetDevname(1,cDevname,iBaudrate);
                    iDriverCheck = JNACom.INSTANCE.SetInit();

                }catch (Exception e){
                    iDriverCheck = -1;
                }

                if (iDriverCheck == 1) {
                    ShowMessage("Failed to open serial port:No serial read/write permission!");
                    return;
                }else {

                    switch (view.getId()) {
                        case R.id.btn_Print1:
                            String strValue  = spinnerpaired.getSelectedItem().toString();
                            ShowPrintClick(strValue);
                            break;
                        case  R.id.btn_Print2:
                            PrintBmp();
                            break;
                        case R.id.btn_Print4:
                            handler.postDelayed(runnable, 2000);
                            mbtn_receiptPrint.setEnabled(false);
                            mbtn_imgPrint.setEnabled(false);
                            mbtn_CyclesPrint.setEnabled(false);
                            mbtn_findFile.setEnabled(false);
                            mbtn_printContent.setEnabled(false);
                            break;
                        case R.id.btn_Print5:
                            showFileTXTChooser();
                            break;
                        case R.id.btn_Print6:
                            if(btn_hex.isChecked()){
                                String textCOMA = edtText5.getText().toString();
                                textCOMA = textCOMA.replace(" ","");
                                if(isHexStrValid(textCOMA.toUpperCase())){
                                    byte[] bytes = hexToByteArr(textCOMA);//将字符串形式表示的十六进制数转换为byte数组
                                    String byteValue = PrintCmd.JNAByteToString(bytes);
                                    JNACom.INSTANCE.PrintTransmitJNA(byteValue, byteValue.length());
                                    if(checkBox.isChecked()){
                                        PrintFeedCutpaper(5);
                                    }
                                }
                                break;
                            }else {
                                String str = edtText5.getText().toString();

                                strValue =PrintCmd.JNAByteToString(PrintCmd.SetClean());
                                JNACom.INSTANCE.PrintTransmitJNA(strValue,strValue.length());

                                strValue =PrintCmd.JNAByteToString(PrintCmd.SetReadZKmode(0));
                                JNACom.INSTANCE.PrintTransmitJNA(strValue,strValue.length());

                                strValue =PrintCmd.JNAByteToString(PrintCmd.PrintString(str,0));
                                JNACom.INSTANCE.PrintTransmitJNA(strValue,strValue.length());

                                if(checkBox.isChecked()) {
                                    PrintFeedCutpaper(10);
                                }
                                break;
                            }
                        default:
                            break;
                    }
                }
            } catch (Exception e) {
                ShowMessage(e.getMessage());
                Log.e(TAG, "PrintClickListener:" + e.getMessage());
            }
        }
    }

    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            String Status = "";
            int iStatus = -1;
            iStatus = PrintStatus();
            // TODO Auto-generated method stub
            // 要做的事情，这里再次调用此Runnable对象，以实现每两秒实现一次的定时器操作
            handler.postDelayed(this, 2000);
            int iCount = Integer.valueOf(m_edtTextCycles.getText().toString());
            String strValue = spinnerpaired.getSelectedItem().toString();
            ShowPrintClick(strValue);
            if(iStatus == 0){
                Status = "";
            }else
            if (iStatus == -1){
                Status = "     Status: Printer is offline or no power";
            }else{
                Status = "     Status:" + PrintCmd.getStatusDescriptionEn(iStatus);
            }
            String msg = iCount+" copies need to be printed and  "+(++printnum)+" copies has been printed"+'\n';
            alertDialog1.setMessage(msg+Status);
            alertDialog1.show();
            Message message = Message.obtain();
            message.what = 3;
            message.obj = msg;
            handler.sendMessage(message);
            if (printnum >= iCount || iStatus != 0) {
                Button button = alertDialog1.getButton(AlertDialog.BUTTON_NEUTRAL);
                if(null==button){
                    Log.i("carter", "button is null");
                }else{
                    button.setText("Ok");
                }
                printnum=0;
                handler.removeCallbacks(runnable);
            }
            else
            {
                Button button = alertDialog1.getButton(AlertDialog.BUTTON_NEUTRAL);
                if(null==button){
                    Log.i("carter", "button is null");
                }else{
                    button.setText("Stop");
                }
            }
        }
    };

    private int PrintBmp() {
        int iResult = 1;
        byte [] byteImg = new byte[0];
        try {
            String strValue = m_edtImage.getText().toString().trim();//edtText3.getText().toString().trim()
            if (strValue.equals("")) {
                ShowMessage("Please select bmp file...");
            } else {
                if (getExtensionName(strValue).equals("txt")) {
                    try{
                        byteImg = PrintBase64(strValue);
                    }catch (Exception e){
                        Message message = new Message();
                        message.what = 4;
                        message.obj = "Base64 file is an error text file";
                        handler.sendMessage(message);
                    }
                    iResult = 0;
                }
                else{
//                    int[] data1 = getBitmapParamsData(strValue);//图片转数组
//                     byteImg = PrintCmd.PrintDiskImagefile(data1, width, heigh);
                         byteImg = PrintCmd.PrintDiskImagefile(strValue);
                    if(byteImg == null){
                        ShowMessage("Picture is too large");
                    }
                }
                    ShowMessage("Print image:" + strValue);
                    int iDataLen = byteImg.length;
                    int iValue = 0 ;
                    int iIndex;
                    int iSendLen = 0;
                    for (iIndex=0;iIndex<iDataLen;iIndex=iIndex+1024)
                    {
                        if(iIndex + 1024> iDataLen)
                        {
                            iSendLen = iDataLen  - iIndex;
                        }
                        else
                        {
                            iSendLen = 1024;
                        }
                        String byteValue = PrintCmd.JNAByteToString(byteImg,iIndex,iIndex+iSendLen);
                        iValue = JNACom.INSTANCE.PrintTransmitJNA(byteValue,byteValue.length());
                        Thread.sleep(30); //2019/11/05由144调整为256，解决打印5K数据问题
                        //USB口使用
                        //usleep(1000*20);
                    }

                    PrintFeedCutpaper(5);

                    if (iValue > 0)
                        iResult = 0;

            }
        } catch (Exception e) {
            ShowMessage(e.getMessage());
        }
        return iResult;
    }

    // 走纸换行，再切纸，清理缓存
    public static void PrintFeedCutpaper(int iLine) throws IOException {
        String strValue =PrintCmd.JNAByteToString(PrintCmd.PrintFeedline(iLine)); // 打印走纸
        JNACom.INSTANCE.PrintTransmitJNA(strValue,strValue.length());
        strValue =PrintCmd.JNAByteToString(PrintCmd.PrintCutpaper(0));
        JNACom.INSTANCE.PrintTransmitJNA(strValue,strValue.length());
    }

    // ----------------------------------------------------保存、获取界面数据
    private void saveSPData() {
        SharedPreferences msharedPreferences = getSharedPreferences("ComDemo",
                Context.MODE_PRIVATE);
        try {
            SharedPreferences.Editor editor = msharedPreferences.edit();
            editor.putString("mSpinnerCOMA", mSpinnerCOMA.getSelectedItem()
                    .toString());
            editor.putString("mSpinnerBaudRateCOMA", mSpinnerBaudRateCOMA
                    .getSelectedItem().toString());
            editor.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // ----------------------------------------------------刷新界面数据
    private void getSPData() {
        SharedPreferences msharedPreferences = getSharedPreferences("ComDemo",
                Context.MODE_PRIVATE);
        try {

            String strValue = msharedPreferences.getString("mSpinnerCOMA", "");

            int iCount = mSpinnerCOMA.getAdapter().getCount();
            int iIndex = 0;
            for (iIndex = 0; iIndex < iCount; iIndex++) {
                if (mSpinnerCOMA.getItemAtPosition(iIndex).toString()
                        .equals(strValue)) {
                    mSpinnerCOMA.setSelection(iIndex);
                    break;
                }
            }
            strValue = msharedPreferences.getString("mSpinnerBaudRateCOMA", "");
            iCount = mSpinnerBaudRateCOMA.getAdapter().getCount();
            for (iIndex = 0; iIndex < iCount; iIndex++) {
                if (mSpinnerBaudRateCOMA.getItemAtPosition(iIndex).toString()
                        .equals(strValue)) {
                    mSpinnerBaudRateCOMA.setSelection(iIndex);
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy(){
        saveSPData();
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    // 显示文件选择路径
    public void showFileChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(intent, "Select a bmp file"), FILE_SELECT_CODE);
        } catch (android.content.ActivityNotFoundException ex) {
            ShowMessage("Please install a File Manager.");
        }
    }

    public void showFileTXTChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("text/plain");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(intent, "Select a txt file"), FILE_SELECT_TXT);
        } catch (android.content.ActivityNotFoundException ex) {
            ShowMessage("Please install a File Manager.");
        }
    }

    // 获取绝对路径
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case FILE_SELECT_CODE:
                if (resultCode == RESULT_OK) {
                    Context context = getApplicationContext();
                    Uri uri = data.getData();
                    String file = null;
                    try{
                        file = GetPathFromUri.getPath(context, uri);
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                    if ("File".equalsIgnoreCase(uri.getScheme()) || (file != null)) {//
                        System.out.println(file);
                        m_edtImage.setText(file);
                        verifyStoragePermissions();
                    } else {
                        file = getStoragePath(context,true);
                        final String docId = DocumentsContract.getDocumentId(uri);
                        final String[] split = docId.split(":");
                        file = file +  "/" + split[1];//"/" + split[0] +
                        m_edtImage.setText(file);//uri.getPath().replace(":","/")uri.getPath()"/storage/emulated/0/pic/2222.bmp"
                        verifyStoragePermissions();
                    }
                }
                break;
            case FILE_SELECT_TXT:
                if (resultCode == RESULT_OK) {
                    Context context = getApplicationContext();
                    Uri uri = data.getData();
                    String file = GetPathFromUri.getPath(context, uri);
                    if ("File".equalsIgnoreCase(uri.getScheme()) || (file != null)) {//
                        String readTxt = ReadTxtFile(file);
                        edtText5.setText(readTxt);//uri.getPath().replace(":","/")uri.getPath()"/storage/emulated/0/pic/2222.bmp"
                        verifyStoragePermissions();
                    } else {
                        file = getStoragePath(context,true);
                        final String docId = DocumentsContract.getDocumentId(uri);
                        final String[] split = docId.split(":");
                        file = file +  "/" + split[1];
                        String readTxt = ReadTxtFile(file);
                        edtText5.setText(readTxt);
                        verifyStoragePermissions();
                    }
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void verifyStoragePermissions() {
        // Check if we have write permission
        int permission = ActivityCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);//缺少什么权限就写什么权限
        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(this, PERMISSIONS_STORAGE, REQUEST_EXTERNAL_STORAGE);
        }
    }



    /**
     * 将字符串形式表示的十六进制数转换为byte数组
     */
    public static byte[] hexStringToBytes(String hexString) {
        hexString = hexString.toLowerCase();
        String[] hexStrings = hexString.split(" ");
        byte[] bytes = new byte[hexStrings.length];
        for (int i = 0; i < hexStrings.length; i++) {
            char[] hexChars = hexStrings[i].toCharArray();
            bytes[i] = (byte) (charToByte(hexChars[0]) << 4 | charToByte(hexChars[1]));
        }
        return bytes;
    }
    private static byte charToByte(char c) {
        return (byte) "0123456789abcdef".indexOf(c);
        // 改成小写 return (byte) "0123456789ABCDEF".indexOf(c);
    }
}
