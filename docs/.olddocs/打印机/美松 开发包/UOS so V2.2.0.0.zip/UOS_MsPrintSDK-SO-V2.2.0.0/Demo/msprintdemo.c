#include <stdio.h>
#include <string.h>  

//gcc compile
//gcc -o msprintdemo msprintdemo.c /lib/libmsprintsdk.so -lstdc++  -lpthread -ldl -ludev

//g++ compile include .h file
//g++ -o msprintdemo msprintdemo.c /lib/libmsprintsdk.so -lstdc++  -lpthread -ldl -ludev

//#define _GPLUS	//g++ compile
#ifdef _GPLUS
extern "C" 
{
	#include "Msprintsdk.h"
}
#endif

int main(int argc,char** argv)
{       
	int cInput=0; 
	int iRes = 1;   	
	char cSendData[3]={0};
	char cReData[3]={0}; 

	while(1)
    {  
		iRes = 1;
		
		if(cInput != '\n')
		{
			printf("\n");
			printf("*-------------------------------------------------------*\n");
			printf("*            Print Demo                                 *\n");    
			printf("*                                                       *\n"); 
			printf("*    1:SetInit(usb/lp0)               			*\n");
			printf("*    2:SetInit(AutoUSB)                                 *\n");
			printf("*    3:SetInit(Config.ini)                              *\n");
			printf("*    4:PrintSelfcheck                 			*\n");
			printf("*    5:Print Ticket                    			*\n");
			printf("*    6:Print test.bmp                             	*\n");
			printf("*    7:PrintTransmit	                             	*\n");
			printf("*    8:GetStatus                                        *\n"); 
			printf("*    9:SetClose                                         *\n");
			printf("*    0:Exit                                             *\n");
			printf("*-------------------------------------------------------*\n");
			printf("     Please Select(0-9):");
		}
        cInput = getchar();

        switch(cInput)
        {
            case '0':
				SetClose();
            	printf("Exit\n\n");
				return 1;
				break;
			case '1': 
				SetDevname(2,"/dev/usb/lp0",0);	
				iRes = 	SetInit(); 
				printf("SetInit Return:%d\n",iRes);
				break;
			case '2': 
				SetDevname(3,"",0);	
				iRes = 	SetInit(); 
				printf("SetInit Return:%d\n",iRes);
				break;
			case '3':  
				iRes = 	SetInit(); 
				printf("SetInit Return:%d\n",iRes);
				break;
			case '4':	
 				iRes = PrintSelfcheck();  
				printf("PrintSelfcheck Return:%d\n",iRes);
				break;
			case '5':
				printf("Print Ticket Sample\n"); 
			
				SetClean(); 
				//SetCommandmode(3); 
			 	SetAlignment(0);  
			  	SetLinespace(30); 

				//SetReadZKmode(0);	
				//PrintString("  ���ĺ�����:"); 
				PrintString("  Your number is:",0); 
			 	SetAlignment(1); 
				SetSizetext(2,2); 
				SetSizechar(2,2,0,1);
				SetBold(1);  
				PrintString("A015",0); 
				SetAlignment(0);  
				SetBold(0); 
				SetSizetext(2,1);  
				//SetSizechar(1,0,0,0);
				//SetSpacechar(5); 
				PrintFeedDot(30); 
				
				//PrintString("  ��ǰ����1�˵Ⱥ�,ע��ҵ�񴰿ڵĺ��к�����Ϣ������������ȡ�š�",0); 
				PrintString("  There are 1 people waiting in front of you, pay attention to the service window of the call number information.",0); 
				PrintFeedDot(30);
				//PrintString("  лл���ĺ���!",0); 
				PrintString("  Thank you for your cooperation!",0); 
				PrintFeedDot(30); 

				SetAlignment(2);  
				PrintString("2019-03-16 09:30 ",0); 

			 	SetAlignment(0);  
				PrintQrcode("www.xxx.com",5,6,0);    
				//or
				/*
				PrintQrcode("www.xxx.com",5,6,1);
				SetLeftmargin(240);
				PrintString("www.xxx.com",1); 
				PrintRemainQR(); 
				*/
				PrintFeedDot(150);
				PrintCutpaper(0);  
				SetClean();				
				break;
			case '6':
 				iRes = PrintDiskbmpfile("test.bmp"); 
				printf("PrintDiskbmpfile Return:%d\n",iRes);
				break;
			case '7': 
				cSendData[0]=0x0A; 
				iRes =PrintTransmit(cSendData,1);
				printf("PrintTransmit Return:%d\n",iRes);

				cSendData[0]=0x10;
				cSendData[1]=0x04;
				cSendData[2]=0x01;
				iRes =GetTransmit(cSendData,3,cReData,10);
				printf("GetTransmit Return:%d;Redata:%d\n",iRes,cReData[0]);

				break; 
			case '8':				
				iRes = 	GetStatus();  
				printf("GetStatus Return:%d\n",iRes); 
				break;  
			case '9':
				iRes = SetClose();
				printf("SetClose Return:%d\n",iRes);
				break;  
		} 
	}
	return 0; 
}  
