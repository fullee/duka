package com.demo.printdemobt;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.DocumentsContract;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import static android.content.ContentValues.TAG;
import static com.demo.printdemobt.GetPathFromUri.getStoragePath;
import static com.msprintsdk.UtilsTools.ReadTxtFile;

public class MainActivity extends Activity {
    Button m_btnConnect;
    private ArrayList<SiriListItem> BluetoothList;
    private ChatListAdapter mAdapter;
    private Context mContext;
    // Get the default Bluetooth adapter 取得默认的蓝牙适配器
    private BluetoothAdapter mBtAdapter = BluetoothAdapter.getDefaultAdapter();
    private boolean m_BlnBlueEnable = true;    //蓝牙打开/关闭状态
    private static final int FILE_SELECT_CODE = 0;
    static final int FILE_SELECT_TXT = 1;
    public static msprintsdk.BluetoothManager m_BluetoothManager = new msprintsdk.BluetoothManager();// 蓝牙管理类
    private clientThread clientConnectThread = null;
    private Spinner m_spnDevice;
    public static Spinner m_spnFun;
    static SimpleDateFormat m_sdfDate = new SimpleDateFormat("HH:mm:ss ");
    public static Button mbtn_getStatus;
    public static Button mbtn_receiptPrint,mbtn_CyclesPrint,mbtn_imgPrint,mbtn_findFile,mbtn_printContent;
    public static Spinner spinnerstutas;
    public static EditText m_edtText2;
    public static EditText m_edtImage;
    public static EditText m_edtTextContent;
    public static CheckBox m_btn_hex;
    public static EditText m_edtTextCycles;
    public static int m_iPrintNum = 0;
    public static AlertDialog m_alertDialog1;
    public static Queue<DataBean> m_printerQueueList = new LinkedList<DataBean>();
    final String[] m_str_Funs = {"PrintLine", "PrintSelfcheck", "Example01"};//,"PrintQrcode"  };
    static final String[] m_nStr_002 = {"GetStatus"};
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE, Environment.DIRECTORY_DOWNLOADS,
            Environment.getExternalStorageDirectory().getAbsolutePath()};

    public static BluetoothSocket m_btSocket = null;
    static String BlueToothAddress = "null";
    static String BlueToothName = "";
    static boolean m_blnConnect = false;
    DataBean m_dataBean = new DataBean(0,"");
    SharedPreferences m_sharedPreferences;
    private BluetoothListenerReceiver m_bleReceiver;

    @Override
    public void onStart() {
        super.onStart();
        // If Bluetooth adapter is not on, request that it be enabled. 如果蓝牙适配器未启用，请求它被启用。
        if (!mBtAdapter.isEnabled()) {
            m_BlnBlueEnable = false;
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, 3);
        }
    }
    @Override
    public void onBackPressed() {
        /*
         * If the Bluetooth adapter is enabled, the request is disabled, when the return key is pressed
         * 当按下返回键时，如果蓝牙适配器之前为停用状态，则请求恢复停用
         */
        if(mBtAdapter.isEnabled() && m_BlnBlueEnable == false)
            mBtAdapter.disable();
        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        try
        {
            mContext = this;

            // 监视蓝牙关闭和打开的状态
            m_bleReceiver = new BluetoothListenerReceiver();
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
            intentFilter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
            intentFilter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
            registerReceiver(m_bleReceiver,intentFilter);
            initCtrl();
            getDeviceList();
            m_sharedPreferences = getSharedPreferences("printdemobt",  Context.MODE_PRIVATE);
            getSPData();
        }catch (Exception e)
        {
            Log.e(TAG, "onCreate:" + e.getMessage());
        }
    }

    // Bound view control 绑定控件
    private void initCtrl() {
        try {
            m_spnDevice = (Spinner) findViewById(R.id.SpinnerBt);
            m_btnConnect = (Button) findViewById(R.id.connected_bluetooth);
            m_spnFun = (Spinner) findViewById(R.id.spinner_001);
            ArrayAdapter<String> adapter001 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, m_str_Funs);
            adapter001.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            m_spnFun.setAdapter(adapter001);

            spinnerstutas = (Spinner) findViewById(R.id.spinner_002);
            ArrayAdapter<String> adapter002 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, m_nStr_002);
            adapter002.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerstutas.setAdapter(adapter002);

            m_edtText2 = (EditText) findViewById(R.id.editText2);
            m_edtText2.setText("");

            m_edtImage = (EditText) findViewById(R.id.editText3);
            m_edtImage.setText("");
            m_edtImage.setOnClickListener(new ButtonClickEvent());
            m_edtImage.setInputType(InputType.TYPE_NULL);

            m_edtTextCycles = (EditText) findViewById(R.id.editCycles);

            m_edtTextContent = (EditText) findViewById(R.id.editText5);
            m_edtTextContent.setText("");

            mbtn_getStatus = (Button) findViewById(R.id.btn_GetStatus);
            mbtn_getStatus.setOnClickListener(new GetClickListener());

            m_btnConnect.setOnClickListener(new ButtonClickEvent());
            mbtn_receiptPrint = (Button) findViewById(R.id.btn_Print1);
            mbtn_receiptPrint.setOnClickListener(new PrintClickListener());

            mbtn_CyclesPrint = (Button) findViewById(R.id.btn_Print2);
            mbtn_CyclesPrint.setOnClickListener(new PrintClickListener());

            mbtn_imgPrint = (Button) findViewById(R.id.btn_Print3);
            mbtn_imgPrint.setOnClickListener(new PrintClickListener());

            mbtn_findFile = (Button) findViewById(R.id.btn_Print5);
            mbtn_findFile.setOnClickListener(new ButtonClickEvent());
            mbtn_printContent = (Button) findViewById(R.id.btn_Print6);
            mbtn_printContent.setOnClickListener(new PrintClickListener());
            m_btn_hex = (CheckBox) findViewById(R.id.btn_hex);
            m_spnDevice.setOnItemSelectedListener(mDeviceClickListener);
            m_alertDialog1 = new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Continuous print")//标题
                    .setIcon(R.mipmap.ic_launcher)//图标
                    .setNeutralButton("Stop", new DialogInterface.OnClickListener() {//添加普通按钮
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            m_iPrintNum = 0;

                            m_dataBean.m_iFunID = 7;
                            m_printerQueueList.add(m_dataBean);

                            mbtn_receiptPrint.setEnabled(true);
                            mbtn_CyclesPrint.setEnabled(true);
                            mbtn_imgPrint.setEnabled(true);
                            mbtn_findFile.setEnabled(true);
                            mbtn_printContent.setEnabled(true);
                            Button button = m_alertDialog1.getButton(AlertDialog.BUTTON_NEUTRAL);
                            if (null == button) {
                                Log.i("carter", "button is null");
                            } else {
                                button.setText("Stop");
                            }
                        }
                    }).create();
            m_alertDialog1.setCanceledOnTouchOutside(false);
            new Thread(new PrintThread()).start();
        }catch (Exception e)
        {
            Log.e(TAG, "initCtrl:" + e.getMessage());
        }
    }

    // Set monitor 设置监听
    // Get the device list 获取设备列表
    private void getDeviceList() {
        BluetoothList = new ArrayList<SiriListItem>();
        mAdapter = new ChatListAdapter(mContext, BluetoothList);
        m_spnDevice.setAdapter(mAdapter);
        SearchBluetoothDevices();
    }

    /*
     * Search for already enabled Bluetooth devices
     */
    private void SearchBluetoothDevices() {
        try
        {
            BluetoothList.clear();
            mAdapter.notifyDataSetChanged();
            // Get a set of currently paired devices 得到一组当前配对的设备
            Set<BluetoothDevice> pairedDevices = mBtAdapter.getBondedDevices();
            if (pairedDevices.size() > 0) {
                for (BluetoothDevice device : pairedDevices) {
                    BluetoothList.add(new SiriListItem(device.getName(),
                            device.getAddress(), true));
                    mAdapter.notifyDataSetChanged();
                    m_spnDevice.setSelection(BluetoothList.size() - 1);
                }
            }
        }catch (Exception e)
        {
            Log.e(TAG, "SearchBluetoothDevices:" + e.getMessage());
        }
    }

    /*
     * All devices in the list view monitor click events
     * 列表视图中所有设备监听点击事件
     */
    private AdapterView.OnItemSelectedListener mDeviceClickListener = new OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
            SiriListItem item = BluetoothList.get(position);
            BlueToothAddress = item.address;
            BlueToothName = item.name;
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    };

    // handler对象，接收消息
    static class MyHandler extends Handler
    {
        WeakReference<Activity> mWeakReference;
        public MyHandler(Activity activity)
        {
            mWeakReference=new WeakReference<Activity>(activity);
        }
        @Override
        public void handleMessage(Message msg)
        {
            final Activity activity=mWeakReference.get();
            // 处理从子线程发送过来的消息
            int arg1 = msg.arg1;  //获取消息携带的属性值
            int arg2 = msg.arg2;
            int what = msg.what;
            Object result = msg.obj;
            switch(what)
            {
                case 0:
                    break;
                case 3:
                case 4:
                    ShowMessage(result.toString());
                    break;
                default:
                    break;
            }
        }
    }

     class ButtonClickEvent implements View.OnClickListener {
        public void onClick(View view) {
            try {
                switch (view.getId()) {
                    case R.id.editText3:
                        showFileChooser();
                        break;
                    case R.id.btn_Print5:
                        showFileTXTChooser();
                        break;
                    case R.id.connected_bluetooth:
                        if(m_btSocket == null || !m_BluetoothManager.isConnected())
                        {
                            if(mBtAdapter.isEnabled())
                            {
                                openBt();
                                m_spnDevice.setEnabled(false);
                            }
                            else
                            {
                                ShowMessage("Bluetooth disabled.");
                            }
                        }else
                        {
                            disConnect();
                            m_spnDevice.setEnabled(true);
                        }
                        break;
                    default:
                        break;
                }
            } catch (Exception e) {
                Log.e(TAG, "CheckClickListener:" + e.getMessage());
            }
        }
    }

    /**
     * 打印机状态查询
     */
    class GetClickListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            try {
                switch (view.getId()) {
                    case R.id.btn_GetStatus:
                    String Value = spinnerstutas.getSelectedItem().toString();
                    if (!m_BluetoothManager.isConnected()) {          // 提示：请先连接打印机
                        ShowMessage("Please connect the device.");
                        return;
                    }else
                    if (Value.equals("GetStatus")) {
                        m_dataBean.m_iFunID = 8;
                        m_printerQueueList.add(m_dataBean);
                    }
                    break;
                    default:
                        break;
                }
            }
            catch (Exception e)
            {
                ShowMessage(e.getMessage());
                Log.e(TAG, "GetClickListener:" + e.getMessage());
            }
        }
    }

    class PrintClickListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            if (!m_BluetoothManager.isConnected()) {          // 提示：请先连接打印机
                ShowMessage("Please connect the device.");
                return;
            }else {
                switch (view.getId()) {
                    case R.id.btn_Print1:
                        m_dataBean.m_iFunID = 1;
                        m_printerQueueList.add(m_dataBean);
                        break;
                    case R.id.btn_Print2:
                        mbtn_receiptPrint.setEnabled(false);
                        mbtn_CyclesPrint.setEnabled(false);
                        mbtn_imgPrint.setEnabled(false);
                        mbtn_findFile.setEnabled(false);
                        mbtn_printContent.setEnabled(false);
                        m_dataBean.m_iFunID = 2;
                        m_printerQueueList.add(m_dataBean);
                        break;
                    case R.id.btn_Print3:
                        m_dataBean.m_iFunID = 3;
                        m_printerQueueList.add(m_dataBean);
                        break;
                    case R.id.btn_Print6:
                        if (m_btn_hex.isChecked()) {
                            m_dataBean.m_iFunID = 6;
                            m_printerQueueList.add(m_dataBean);
                            break;
                        } else {
                            m_dataBean.m_iFunID = 5;
                            m_printerQueueList.add(m_dataBean);
                            break;
                        }
                    default:
                        break;
                }
            }
        }
    }

    // disconnect 断开连接
    private void disConnect() {
        if(m_blnConnect) {
            shutdownClient();
            m_blnConnect = false;
            m_btnConnect.setText("Connect");
            ShowMessage("Device disconnect.");
        }
    }

    private void getSPData() {
        try {
            String strValue = m_sharedPreferences.getString("devicemacaddr", "");

            int iCount = m_spnDevice.getAdapter().getCount();
            int iIndex = 0;
            for (iIndex = 0; iIndex < iCount; iIndex++) {
                SiriListItem item = BluetoothList.get(iIndex);
                if (strValue.equals(item.address)) {
                    m_spnDevice.setSelection(iIndex);
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // Siri list item Siri列表项
    public class SiriListItem {
        String name;
        String address;
        public String message;
        public boolean isSiri;
        public SiriListItem(String name,String address, boolean siri) {
            this.name = name;
            this.address = address;
            this.message = name  + "\n" + address;
            isSiri = siri;
        }
        public SiriListItem(String message, boolean siri) {
            this.name = "";
            this.address = "";
            this.message = message;
            isSiri = siri;
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        disConnect();
        unregisterReceiver(m_bleReceiver);
    }

    public void openBt(){
        String address = BlueToothAddress;
        if (!address.equals("null")) {
            m_BluetoothManager.setServerAddress(address);
            clientConnectThread = new clientThread();
            clientConnectThread.start();
            m_blnConnect = true;
        } else { // 提示：蓝牙地址为空
            m_blnConnect = false;
            ShowMessage("No party device.");
        }
        return;
    }

    private Handler LinkDetectedHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            try
            {
                ShowMessage((String) msg.obj);

                switch(msg.what)
                {
                    case 11:
                        m_btnConnect.setText("Disconnect");
                        SharedPreferences.Editor editor = m_sharedPreferences.edit();
                        editor.putString("devicemacaddr",  BlueToothAddress);
                        editor.commit();
                        break;
                }
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    // 开启客户端
    private class clientThread extends Thread {
        public void run() {
            try {
                Message msg2 = new Message();
                msg2.obj = "Connecting device:" + BlueToothName + " " +  BlueToothAddress + " ......";
                msg2.what = 0;
                LinkDetectedHandler.sendMessage(msg2);
                // 创建一个Socket连接：只需要服务器在注册时的UUID号
                m_btSocket = m_BluetoothManager.connectServer();

                if(m_btSocket != null && m_BluetoothManager.isConnected()){
                    // 提示连接成功，可以发送指令
                    Message msg = new Message();
                    msg.obj = "Device connected successfully.";
                    msg.what = 11;
                    LinkDetectedHandler.sendMessage(msg);
                }else{
                    Message msg = new Message();
                    msg.obj = "Device connected failed.";
                    msg.what = 0;
                    LinkDetectedHandler.sendMessage(msg);
                    m_spnDevice.setEnabled(true);
                }
            } catch (Exception e) {
                Log.e("connect", "", e);
                Message msg = new Message();
                msg.obj = "Connection server exception,Disconnect and try again.";
                msg.what = 0;
                LinkDetectedHandler.sendMessage(msg);
            }
        }
    }

    // Disconnect
    private void shutdownClient() {
        new Thread() {
            public void run() {
                if (clientConnectThread != null) {
                    clientConnectThread.interrupt();
                    clientConnectThread = null;
                }
                m_BluetoothManager.shutdownClient();
            };
        }.start();
    }

    //显示信息
    public static void ShowMessage(String sMsg) {
        StringBuilder sbMsg = new StringBuilder();
        sbMsg.append(m_edtText2.getText());
        sbMsg.append(m_sdfDate.format(new Date()));
        sbMsg.append(sMsg);
        sbMsg.append("\r\n");
        m_edtText2.setText(sbMsg);
        m_edtText2.setSelection(sbMsg.length(), sbMsg.length());
    }

    // 获取位图文件路径
    private void showFileChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(
                    Intent.createChooser(intent, "Select a image file"),
                    FILE_SELECT_CODE);
        } catch (android.content.ActivityNotFoundException ex) {
            ShowMessage("Please install a File Manager.");
            Toast.makeText(this, "Please install a File Manager.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    public void showFileTXTChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("text/plain");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(intent, "Select a txt file"), FILE_SELECT_TXT);
        } catch (android.content.ActivityNotFoundException ex) {
            ShowMessage("Please install a File Manager.");
            Toast.makeText(this, "Please install a File Manager.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case FILE_SELECT_CODE:
                if (resultCode == RESULT_OK) {
                    Context context = getApplicationContext();
                    Uri uri = data.getData();
                    String file = null;
                    try{
                        file = GetPathFromUri.getPath(context, uri);
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                    if ("File".equalsIgnoreCase(uri.getScheme()) || (file != null)) {//
                        System.out.println(file);
                        m_edtImage.setText(file);
                        verifyStoragePermissions();
                    } else {
                        file = getStoragePath(context,true);
                        final String docId = DocumentsContract.getDocumentId(uri);
                        final String[] split = docId.split(":");
                        file = file +  "/" + split[1];//"/" + split[0] +
                        m_edtImage.setText(file);//uri.getPath().replace(":","/")uri.getPath()"/storage/emulated/0/pic/2222.bmp"
                        verifyStoragePermissions();
                    }
                }
                break;
            case FILE_SELECT_TXT:
                if (resultCode == RESULT_OK) {
                    Context context = getApplicationContext();
                    Uri uri = data.getData();
                    String file = GetPathFromUri.getPath(context, uri);
                    if ("File".equalsIgnoreCase(uri.getScheme()) || (file != null)) {//
                        String readTxt = ReadTxtFile(file);
                        m_edtTextContent.setText(readTxt);//uri.getPath().replace(":","/")uri.getPath()"/storage/emulated/0/pic/2222.bmp"
                        verifyStoragePermissions();
                    } else {
                        file = getStoragePath(context,true);
                        final String docId = DocumentsContract.getDocumentId(uri);
                        final String[] split = docId.split(":");
                        file = file +  "/" + split[1];
                        String readTxt = ReadTxtFile(file);
                        m_edtTextContent.setText(readTxt);
                        verifyStoragePermissions();
                    }
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    public void verifyStoragePermissions() {
        // Check if we have write permission
        int permission = ActivityCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);//缺少什么权限就写什么权限
        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(this, PERMISSIONS_STORAGE, REQUEST_EXTERNAL_STORAGE);
        }
    }

    public class BluetoothListenerReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()) {
                case BluetoothAdapter.ACTION_STATE_CHANGED:
                    int blueState = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, 0);
                    switch (blueState) {
                        case BluetoothAdapter.STATE_TURNING_ON: //蓝牙打开中
                            break;
                        case BluetoothAdapter.STATE_ON:     //蓝牙打开
                            SearchBluetoothDevices();
                            break;
                        case BluetoothAdapter.STATE_TURNING_OFF:    //蓝牙关闭中
                            break;
                        case BluetoothAdapter.STATE_OFF:    //蓝牙关闭
                            disConnect();
                            m_spnDevice.setEnabled(true);
                            break;
                    }
                    break;
                case BluetoothDevice.ACTION_ACL_CONNECTED:  //蓝牙设备已连接
                    break;
                case BluetoothDevice.ACTION_ACL_DISCONNECTED:
                    BluetoothDevice device2 = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                        if(device2.getAddress().equals(m_BluetoothManager.getServerAddress()))
                            disConnect();
                    m_spnDevice.setEnabled(true);
                    break;
            }
        }
    }
}

