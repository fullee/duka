package com.demo.printdemobt;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.widget.Button;

import java.io.IOException;
import java.util.regex.Pattern;

import com.msprintsdk.PrintCmd;

import static android.content.ContentValues.TAG;
import static com.demo.printdemobt.MainActivity.m_alertDialog1;
import static com.demo.printdemobt.MainActivity.m_edtImage;
import static com.demo.printdemobt.MainActivity.m_edtTextContent;
import static com.demo.printdemobt.MainActivity.m_edtTextCycles;
import static com.demo.printdemobt.MainActivity.m_BluetoothManager;
import static com.demo.printdemobt.MainActivity.m_printerQueueList;
import static com.demo.printdemobt.MainActivity.m_iPrintNum;
import static com.demo.printdemobt.MainActivity.m_spnFun;
import static com.msprintsdk.UtilsTools.byteSub;
import static com.msprintsdk.UtilsTools.data;
import static com.msprintsdk.UtilsTools.hexToByteArr;

public  class PrintThread extends Activity implements Runnable {
    public boolean m_blnRun = true;
    MainActivity mainActivity = new MainActivity();
    Handler handler =  new MainActivity.MyHandler(mainActivity);

    @Override
    public  void run() {
        Looper.prepare();
        DataBean printData;

        while (m_blnRun) {
            try {
                if (mainActivity.m_btSocket != null && m_BluetoothManager.isConnected()) {
                    //设置为false就行了
                    while ((printData = m_printerQueueList.poll())!= null) {
                        switch (printData.m_iFunID) {
                            case 1:
                                String strValue = m_spnFun.getSelectedItem().toString();
                                try{
                                    ShowPrintClick(strValue);
                                }catch (Exception e){
                                    Message message = new Message();
                                    message.what = 4;
                                    message.obj = e.getMessage();;
                                    handler.sendMessage(message);
                                }
                                break;
                            case 2:
                                handler.postDelayed(runnable, 2000);
                                break;
                            case 3:
                                PrintBmp();
                                break;
                            case 4:
                                PrintCycle();
                                break;
                            case 5:
                                String str = m_edtTextContent.getText().toString();
                                m_BluetoothManager.send(PrintCmd.SetClean());
                                m_BluetoothManager.send(PrintCmd.SetReadZKmode(0));
                                m_BluetoothManager.send(PrintCmd.PrintString(str,0));
                                m_BluetoothManager.send(PrintCmd.PrintFeedline(3)); // 打印走纸
                                break;
                            case 6:
                                String textCOMA = m_edtTextContent.getText().toString();
                                textCOMA = textCOMA.replace(" ","");
                                if(isHexStrValid(textCOMA.toUpperCase())){
                                    byte[] bytes = hexToByteArr(textCOMA);//将字符串形式表示的十六进制数转换为byte数组
                                    m_BluetoothManager.send(bytes);
                                    m_BluetoothManager.send(PrintCmd.PrintFeedline(1)); // 打印走纸
                                }else{
                                    Message message = new Message();
                                    message.what = 4;
                                    message.obj = "Please input hexadecimal";
                                    handler.sendMessage(message);
                                }
                                break;
                            case 7:
                                m_iPrintNum=0;
                                handler.removeCallbacks(runnable);
                                break;
                            case 8:
                                PrintStatus();
                                break;
                            case  9:
                                break;
                        }
                        Thread.sleep(200);
                    }
                } else {
                    Thread.sleep(100);
                }
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        Looper.loop();
    }

    /**
     * 将字符串形式表示的十六进制数转换为byte数组
     */
    public static byte[] hexStringToBytes(String hexString) {
        hexString = hexString.toLowerCase();
        String[] hexStrings = hexString.split(" ");
        byte[] bytes = new byte[hexStrings.length];
        for (int i = 0; i < hexStrings.length; i++) {
            char[] hexChars = hexStrings[i].toCharArray();
            bytes[i] = (byte) (charToByte(hexChars[0]) << 4 | charToByte(hexChars[1]));
        }
        return bytes;
    }

    public static boolean isHexStrValid(String str) {
        String pattern = "^[0-9A-F]+$";
        return Pattern.compile(pattern).matcher(str).matches();
    }

    private static byte charToByte(char c) {
        return (byte) "0123456789abcdef".indexOf(c);
        // 改成小写 return (byte) "0123456789ABCDEF".indexOf(c);
    }

    //显示记录并走纸
    public void ShowPrintClick(String strValue) {
        if (strValue.equals("PrintLine")) {
            m_BluetoothManager.send(PrintCmd.SetReadZKmode(0)); //中文模式
            m_BluetoothManager.send(PrintCmd.PrintString("123456789abcd中华人民共和国",0));
            m_BluetoothManager.send(PrintCmd.SetClean()); // 清理缓存
        }else
        if(strValue.equals("PrintSelfcheck")){
            m_BluetoothManager.send(PrintCmd.PrintSelfcheck());
        }else
        if(strValue.equals("Example01")){
            byte[] bSendData;
            String strdata = "1D 76 30 00 30 00 5D 00 00 00 00 00 00 00 00 00 00 00 03 FF C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 3F FF F8 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 FF FF FF 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 FF FF FF 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 FF FF FF 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 1F FF FF FF C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF FF FF FF E0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 03 F0 00 0F FF F0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 06 00 00 03 FF FE 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 06 00 00 03 FF FE 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 08 00 00 00 FF FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 08 00 00 00 FF FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 70 00 00 00 3F FF 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 01 00 00 00 00 1F FF 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 0F FF 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 FF C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 FF C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 FF C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 FF C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF F0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 7F FF FF 80 00 01 FE 00 00 00 00 3F C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 7F FF FF 80 00 01 FE 00 00 00 00 3F C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 7F FF FF 80 00 03 FE 00 00 00 00 3F C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 7F FF FF 80 00 03 FE 00 00 00 00 7F C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 7F FF FF 80 00 03 FE 00 00 00 00 7F C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 7F FF FF 80 00 03 FC 00 00 00 00 7F C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF C0 00 00 00 00 00 00 00 00 00 7F 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF C0 00 00 00 00 00 00 00 00 00 7F 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF C0 00 00 00 00 00 00 00 00 00 7F 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF C0 00 00 00 0F FC 00 FF F8 0F FF FC 07 FF F0 0F F0 7F C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF C0 00 00 00 0F FC 00 FF F8 0F FF FC 07 FF F0 0F F0 7F C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF 00 00 00 00 0F FC 07 FF FF 0F FF FC 3F FF F8 0F F3 FF E0 00 00 00 00 00 00 00 00 00 00 00 00 C0 00 00 30 C0 00 00 00 00 00 00 18 00 00 00 00 FF 00 00 00 00 0F F8 1F FF FF 1F FF FC FF FF FC 0F FF FF F0 00 00 00 30 00 30 00 00 00 00 00 00 E0 00 00 30 C0 00 00 33 06 00 00 1C 00 00 00 03 FF FF FE 03 C0 0F F8 1F F3 FF C0 FF 81 FF 8F FC 1F FF FF F0 00 00 00 30 07 F8 00 00 00 00 00 00 E0 00 00 71 C0 00 06 3B 1F 00 00 38 00 00 00 03 FF FF FE 03 C0 0F F8 FF C0 7F C0 FF 01 FF 03 FE 1F F0 3F F0 00 00 00 1F FC 30 00 01 80 00 00 60 E0 00 00 71 80 00 07 F3 F6 00 00 30 60 00 00 03 FF FF FE 03 C0 0F F8 FF C0 7F C0 FF 01 FF 03 FE 1F F0 3F F0 00 00 00 1C 30 30 00 01 80 00 00 30 C0 00 00 E1 80 C0 06 33 06 00 00 67 F0 00 00 03 FF FF FE 03 C0 0F F8 FF C0 7F C0 FF 01 FF 03 FE 1F F0 3F F0 00 00 00 18 30 30 00 00 C0 00 00 1C C0 00 00 C3 1F C0 06 33 06 00 00 FC E0 00 00 03 FF FF F0 0F C0 3F F9 FF C0 7F C0 FF 03 FC 03 FE 1F E0 3F F0 00 00 00 18 30 30 00 00 E0 00 00 1C C0 00 01 C7 F1 80 06 33 0C 00 01 C1 C0 00 00 03 FF FF F0 0F C0 3F F9 FF C1 FF C7 FF 03 FC 03 FE 1F E0 3F E0 00 00 00 18 30 30 00 00 60 00 00 0C C0 00 03 C6 33 00 06 33 6C 00 03 F3 80 00 00 03 FF 00 00 00 00 3F F1 FF FF FF C7 FF 0F FC 03 FE 1F E0 7F E0 00 00 00 18 37 B0 00 00 71 80 00 01 C0 00 07 CC 33 00 06 F3 3C 00 07 1F 00 00 00 0F FE 00 00 00 00 3F F1 FF FF FF C7 FF 0F FC 03 FC 1F E0 7F E0 00 00 00 1B FE 30 00 00 70 C0 00 01 80 C0 06 DB 30 00 07 F3 1C 00 0E 0E 00 00 00 0F FE 00 00 00 00 3F F3 FF 00 00 07 FE 0F F8 03 FC FF E0 7F E0 00 00 00 18 30 30 00 C0 00 60 00 01 9F C0 0C C3 BC 00 06 33 00 00 18 1F 80 00 00 0F FE 00 00 00 00 3F F3 FF 00 00 07 FE 0F F8 03 FC FF E0 7F E0 00 00 00 18 30 30 00 C0 00 38 00 3F F1 C0 18 C7 37 00 06 33 0F 00 00 39 C0 00 00 0F FE 00 00 00 00 3F F3 FF 00 00 07 FE 0F F8 03 FC FF E0 7F E0 00 00 00 18 30 30 00 D8 00 3C 01 F3 81 80 00 CE 33 80 06 33 FE 00 00 F8 F0 00 00 0F FE 00 00 00 00 7F F3 FF 00 00 07 FE 0F F8 03 FC FF C0 7F C0 00 00 00 18 31 B0 01 D8 00 1C 00 03 01 80 00 D8 31 C0 06 F3 06 00 01 DC 3C 00 00 0F FE 00 00 00 00 7F F3 FF 01 FF 0F FE 0F F8 0F F8 FF C0 7F C0 00 00 00 18 7F B0 01 D8 00 0C 00 03 01 80 00 F1 B0 C0 07 B3 C6 00 07 1C 1F 00 00 0F F8 00 00 00 00 7F 83 FF 03 FC 0F FE 0F F8 3F F8 FF C0 7F C0 00 00 00 1F F0 30 01 9C 00 00 00 07 01 80 01 C0 F0 00 0C 33 6C 00 1C 18 7F F0 00 1F FF FF E0 00 00 7F 81 FF DF FC 0F FF 0F FF 7F F1 FF C1 FF C0 00 00 00 30 30 30 01 8C 00 00 00 06 E1 80 00 C0 70 00 0C 33 6C 00 70 1F F3 00 00 1F FF FF E0 00 00 7F 81 FF FF F8 0F FF 83 FF FF 81 FF C1 FF C0 00 00 00 30 30 30 03 8C 03 00 00 06 73 80 00 06 3C 00 0C 33 3C 00 C7 F8 60 00 00 1F FF FF E0 00 00 7F 81 FF FF F8 0F FF 83 FF FF 81 FF C1 FF C0 00 00 00 30 30 30 07 86 03 00 00 0C 33 00 03 03 87 00 0C 33 18 00 00 38 60 00 00 1F FF FF E0 00 00 7F 81 FF FF F8 0F FF 83 FF FF 81 FF C1 FF C0 00 00 00 30 30 30 03 06 03 00 00 1C 33 00 03 61 C3 C0 0C 33 18 00 00 30 60 00 00 1F FF FF E0 00 00 FF 80 FF FF F0 0F FF 01 FF FF 01 FF 01 FF 00 00 00 00 60 30 30 03 03 01 80 00 18 03 00 03 60 C0 E0 18 33 3C 00 00 70 60 00 00 1F FF FF E0 00 00 FF 80 0F FE 00 07 FF 00 FF FC 01 FF 01 FF 00 00 00 00 60 30 30 00 03 81 80 00 30 03 00 07 30 00 60 18 33 7E 00 00 60 E0 00 00 00 00 00 00 00 00 FF 00 00 00 00 00 00 00 00 00 01 00 00 00 00 00 00 00 E0 30 30 00 01 E1 80 00 71 87 00 07 18 00 00 18 33 67 00 00 E0 C0 00 00 00 00 00 00 00 00 FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 C0 31 B0 00 00 79 C0 00 E0 C6 00 0E 0C 0C 00 31 B3 C3 C0 01 D8 C0 00 00 00 00 00 00 00 00 FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 01 80 30 F0 00 00 0F C0 01 C0 76 00 0E 07 0C 00 30 F3 C3 F0 03 8E C0 00 00 00 00 00 00 00 03 FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 03 00 30 70 00 00 00 00 03 80 3E 00 00 01 CE 00 60 73 80 00 06 07 C0 00 00 00 00 00 00 00 03 FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 30 00 00 00 00 06 00 1C 00 00 00 7E 00 00 33 00 00 0C 03 80 00 00 00 00 00 00 00 1F FE 00 00 00 00 1F F0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 1C 00 0C 00 00 00 00 00 00 00 00 00 38 01 80 00 00 00 00 00 00 00 1F FE 00 00 00 00 3F E0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 1F FC 00 00 00 00 FF E0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 1F FC 00 00 00 00 FF E0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF C0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 03 FF 80 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 03 FF 80 00 00 00 01 02 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 FF 80 00 21 E0 01 83 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 02 00 00 00 00 00 0F FF 00 00 3E 40 01 02 00 00 1E 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 02 00 00 00 00 00 0F FF 00 00 27 80 01 02 60 21 E4 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 3F F8 00 00 78 80 02 3F 80 10 48 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 01 00 00 00 00 00 7F F0 00 00 40 80 02 44 00 10 30 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 01 C0 00 00 00 01 FF E0 00 00 4F 80 1F 87 80 02 3E 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 01 C0 00 00 00 01 FF E0 00 00 F8 00 24 79 00 03 C2 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 C0 00 00 00 03 FF C0 00 00 A0 00 04 09 E0 12 44 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 E0 00 00 00 0F FF 00 00 00 47 E0 06 FF 03 E3 F4 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 E0 00 00 00 0F FF 00 00 00 FA 40 19 12 00 44 88 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 38 00 00 00 3F FC 00 00 03 24 80 68 1E 00 44 88 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 1F 00 00 03 FF F8 00 00 04 48 81 8B F0 00 47 E8 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 80 00 0F FF F0 00 00 18 91 00 11 20 00 49 10 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 07 80 00 0F FF F0 00 00 23 22 00 11 3C 00 89 10 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 03 FC 03 FF FF 80 00 00 04 42 00 12 20 00 9A A0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 03 FC 03 FF FF 80 00 00 18 84 00 23 C0 0F D2 60 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF FF FF FC 00 00 00 23 28 01 24 60 00 38 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 7F FF FF F0 00 00 00 0C 30 00 C8 18 00 07 8C 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 0F FF FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF E0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF E0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF E0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 ";
            bSendData = hexStringToBytes(strdata);
            m_BluetoothManager.send(bSendData,1024,10);

            m_BluetoothManager.send(PrintCmd.SetReadZKmode(0));
            PrintCmd.PrintFeedDot(30);
            StringBuilder m_sbData;
            m_sbData = new StringBuilder("店号：8888          机号：100001");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));
            m_sbData = new StringBuilder("电话:0755-12345678");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));
            //PrintFeedDot(20);
            m_sbData = new StringBuilder("收银：01-店长");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));
            m_sbData = new StringBuilder("时间：" + data());
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));
            m_sbData = new StringBuilder("-------------------------------");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));
            byte[] bByte = new byte[3];
            bByte[0] = 12;
            bByte[1] = 18;
            bByte[2] = 26;
            m_BluetoothManager.send(PrintCmd.SetHTseat(bByte, 3));

            m_sbData = new StringBuilder("代码");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 1));
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_sbData = new StringBuilder("单价");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 1));
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_sbData = new StringBuilder("数量");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 1));
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_sbData = new StringBuilder("金额");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));

            m_sbData = new StringBuilder("48572819");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 1));
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_sbData = new StringBuilder("2.00");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 1));
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_sbData = new StringBuilder("3.00");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 1));
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_sbData = new StringBuilder("6.00");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));
            m_sbData = new StringBuilder("怡宝矿泉水");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));
            m_sbData = new StringBuilder("48572820");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 1));
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_sbData = new StringBuilder("2.50");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 1));
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_sbData = new StringBuilder("2.00");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 1));
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_sbData = new StringBuilder("5.00");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));
            m_sbData = new StringBuilder("百事可乐(罐装)");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));
            m_sbData = new StringBuilder("-------------------------------");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));
            m_sbData = new StringBuilder("合计：");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 1));
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_sbData = new StringBuilder("5.00");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 1));
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_sbData = new StringBuilder("11.00");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));

            m_sbData = new StringBuilder("优惠：");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 1));
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_sbData = new StringBuilder(" 0.00");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));

            m_sbData = new StringBuilder("应付：");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 1));
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_sbData = new StringBuilder("11.00");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));

            m_sbData = new StringBuilder("微信支付：");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 1));
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_sbData = new StringBuilder("11.00");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));

            m_sbData = new StringBuilder("找零：");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 1));
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_BluetoothManager.send(PrintCmd.PrintNextHT());
            m_sbData = new StringBuilder(" 0.00");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));

            m_sbData = new StringBuilder("-------------------------------");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));
            m_sbData = new StringBuilder("会员：");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));
            m_sbData = new StringBuilder("券号：");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));
            m_sbData = new StringBuilder("-------------------------------");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));
            PrintCmd.PrintFeedDot(20);
            m_sbData = new StringBuilder("手机易捷通：ejeton.com.cn ");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));
            m_sbData = new StringBuilder("客户热线：400-6088-160");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));
            m_sbData = new StringBuilder("微信号：ejeton ");
            m_BluetoothManager.send(PrintCmd.PrintString(m_sbData.toString(), 0));
            m_BluetoothManager.send(PrintCmd.PrintFeedline(1));
            m_sbData = new StringBuilder("http://weixin.qq.com/r/R3VZQQDEi130rUQi9yBV");
            m_BluetoothManager.send(PrintCmd.PrintQrcode(m_sbData.toString(), 12, 1, 0));
            m_BluetoothManager.send(PrintCmd.PrintFeedline(5));
        }
//        else   if(strValue.equals("PrintQrcode")){
//            m_BluetoothManager.send(PrintCmd.PrintQrcode("http://weixin.qq.com/r/R3VZQQDEi130rUQi9yBV", 12, 2, 0));
//            m_BluetoothManager.send(PrintCmd.PrintFeedline(4));
//        }
    }

    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            int iStatus = 0;//-1
//            iStatus = PrintStatus();//PrintStatus()
            // TODO Auto-generated method stub
            // 要做的事情，这里再次调用此Runnable对象，以实现每两秒实现一次的定时器操作
            handler.postDelayed(this, 2000);
            int iCount = Integer.valueOf(m_edtTextCycles.getText().toString());
            String strValue = m_spnFun.getSelectedItem().toString();
            ShowPrintClick(strValue);
            String Status = "";
            if (iStatus == 0) {
                Status = "";
            } else if (iStatus == -1) {
                Status = "     Status: Printer is offline or no power";
            } else {
                Status = "     Status:" + PrintCmd.getStatusDescriptionEn(iStatus);
            }
            String msg = iCount + " copies need to be printed and  " + (++m_iPrintNum) + " copies has been printed" + '\n';
            m_alertDialog1.setMessage(msg + Status);
            m_alertDialog1.show();
            Message message = Message.obtain();
            message.what = 3;
            message.obj = msg;
            handler.sendMessage(message);
            if (m_iPrintNum >= iCount || iStatus != 0) {
                Button button = m_alertDialog1.getButton(AlertDialog.BUTTON_NEUTRAL);
                if (null == button) {
                    Log.i("carter", "button is null");
                } else {
                    button.setText("Ok");
                }
                m_iPrintNum = 0;
                handler.removeCallbacks(runnable);
            }
        }
    };

    private int PrintBmp() {
        int iResult = 1;
        try {
            String strValue = m_edtImage.getText().toString().trim();//edtText3.getText().toString().trim()
            if (strValue.equals("")) {
                Message message = Message.obtain();
                message.what = 3;
                message.obj = "Please select bmp file...";
                handler.sendMessage(message);
            } else {
//                 int[] data1 = getBitmapParamsData(strValue);//图片转数组
//                  byte [] byte2 = PrintDiskImagefile(data1, width, heigh);
                    byte [] byte1 = PrintCmd.PrintDiskImagefile(strValue);
                    if(byte1 == null){
                        Message message = Message.obtain();
                        message.what = 3;
                        message.obj = "The picture is too large";
                        handler.sendMessage(message);
                        //m_BluetoothManager.send(PrintCmd.SetClean());
                    }
                    Message message = Message.obtain();
                    message.what = 3;
                    message.obj = "Print image:" + strValue;
                    handler.sendMessage(message);

                    int iIndex = 0;
                    int iSendLen = 0;
                    int iRowHeight = 0;

                    //将图片切块打印
                    int iWidth = ((byte1[4]+256)%256)+((byte1[5]+256)%256)*256;
                    int iHeight =((byte1[6]+256)%256)+((byte1[7]+256)%256)*256;
                    iRowHeight = 64;    //切块高度
                    for(int iRowIndex = 0;iRowIndex<iHeight;iRowIndex=iRowIndex+iRowHeight)
                    {
                        if(iRowIndex + iRowHeight> iHeight)
                        {
                            iRowHeight = iHeight-iRowIndex;
                        }
                        iSendLen = iWidth*iRowHeight+8;

                        iIndex = iRowIndex*iWidth;
                        byte1[iIndex++]=0x1D;
                        byte1[iIndex++]=0x76;
                        byte1[iIndex++]=0x30;
                        byte1[iIndex++]=0x0;
                        byte1[iIndex++]=(byte)iWidth;
                        byte1[iIndex++]=(byte)(iWidth>>8);
                        byte1[iIndex++]=(byte)iRowHeight;
                        byte1[iIndex++]=0x0;
                        iIndex = iIndex - 8;
                        m_BluetoothManager.send(byteSub(byte1,iIndex,iSendLen));
                        Thread.sleep(5);
                    }
                    m_BluetoothManager.send(PrintCmd.PrintFeedline(2));
                    iResult = 0;
            }
        } catch (Exception e) {
            Message message = Message.obtain();
            message.what = 3;
            message.obj = e.getMessage();
            handler.sendMessage(message);
            Log.e(TAG, "PrintBmp:" + e.getMessage());
        }
        return iResult;
    }

    private int PrintStatus() {
        int iResult = 1;
        int iValue = -1;
        try {
            byte[] bRead1 = new byte[1];
            String strValue = "";
            Message message = Message.obtain();
            message.what = 4;

            bRead1 = m_BluetoothManager.read(PrintCmd.GetStatus1());

            iValue = PrintCmd.CheckStatus1(bRead1[0]);
            if(iValue!=0) {
                strValue = PrintCmd.getStatusDescriptionEn(iValue);
                message.obj = strValue;
                handler.sendMessage(message);
            }
            if(iValue == 0) {
                iValue = -1;

                    bRead1 = m_BluetoothManager.read(PrintCmd.GetStatus4());
                iValue = PrintCmd.CheckStatus4(bRead1[0]);
                if(iValue!=0) {
                    strValue = PrintCmd.getStatusDescriptionEn(iValue);
                    message.obj = strValue;
                    handler.sendMessage(message);
                }
            }
            if(iValue==0) {
                strValue = PrintCmd.getStatusDescriptionEn(iValue);
                message.obj = strValue;
                handler.sendMessage(message);
            }
        } catch (IOException e) {
            Message message = Message.obtain();
            message.what = 3;
            message.obj = e.getMessage();
            handler.sendMessage(message);
            e.printStackTrace();
        }
        iResult = iValue;
        return iResult;
    }

    private int PrintCycle()
    {
        int iStatus = -1;
        try {
            Message message = Message.obtain();
            handler.postDelayed(runnable, 2000);
        }
        catch(Exception e)
        {
            Message message = Message.obtain();
            message.what = 3;
            message.obj = e.getMessage();
            handler.sendMessage(message);
            Log.e(TAG, "PrintCycle:" + e.getMessage());
        }
        return iStatus;
    }
}