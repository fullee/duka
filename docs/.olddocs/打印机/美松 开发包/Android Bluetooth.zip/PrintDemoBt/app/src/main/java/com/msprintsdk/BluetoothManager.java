package msprintsdk;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.util.Log;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.UUID;

/**
 * 蓝牙管理类
 * @author masung-wangxy
 */
public class BluetoothManager {
	public static final String SPP_UUID = "00001101-0000-1000-8000-00805F9B34FB";// 蓝牙串口服务
	public static final String ACTION_PAIRING_REQUEST = "android.bluetooth.device.action.PAIRING_REQUEST";
	public static final String PROTOCOL_SCHEME_L2CAP = "btl2cap";
	public static final String PROTOCOL_SCHEME_RFCOMM = "btspp";
	public static final String PROTOCOL_SCHEME_BT_OBEX = "btgoep";
	public static final String PROTOCOL_SCHEME_TCP_OBEX = "tcpobex";
	private BluetoothServerSocket mserverSocket = null;
	private BluetoothSocket socket = null;
	private BluetoothDevice device = null;
	private readThread mreadThread = null;

	private BluetoothAdapter mBluetoothAdapter = BluetoothAdapter
			.getDefaultAdapter();
	//private Handler mLinkDetectedHandler = null; 
	private static String mPrinterName = "MS";
	private static String mPrinterPassword = "1234"; 
	private OutputStream mOutputStream = null;
	@SuppressWarnings("unused")
	private InputStream mInputStream = null;


	public void setServerAddress(String address) {
		this.device = this.mBluetoothAdapter.getRemoteDevice(address);
	}

	public String getServerAddress() {
		return this.device.getAddress() ;
	}

	/**
	 *  连接服务端 （通过BluetoothSocket）
	 * @return BluetoothSocket
	 * @throws IOException
	 */
	public BluetoothSocket connectServer() {
		try {
			this.socket = this.device.createRfcommSocketToServiceRecord(UUID
					.fromString(SPP_UUID));
			this.socket.connect();
			startReceive();
		} catch (IOException e) {
			e.printStackTrace();
			this.socket = null;
		}

		return this.socket;
	}
	
	// 开始接收（启动线程）
	public void startReceive() {
		this.mreadThread = new readThread();
		this.mreadThread.start();
	}
	// 获得服务端输入流
	public InputStream getServerInputStream() throws IOException {
		InputStream mmInStream = null;
		if (this.socket != null)
			mmInStream = this.socket.getInputStream();
		return mmInStream;
	}
	
	// 获得输出流
	public OutputStream getOutputStream() throws IOException {
		if (this.socket != null){
			mOutputStream = this.socket.getOutputStream();
			return mOutputStream;
		}
		return null;
	}

	// 发送指令数组
	public void send(byte[] bSend) {
		try {
			if (bSend.length != 0) {
//				mOutputStream = getOutputStream();
//				mOutputStream.write(bSend);
				mOutputStream = getOutputStream();
				ByteBuffer bb = ByteBuffer.wrap(bSend);
				mOutputStream.write(bb.array());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// 分次发送指令数组
	public void send(byte[] bSend,int iModlen,int iSleep) {
		try {
			mOutputStream = getOutputStream();

			int iLength = bSend.length;
			int iSendlen = iModlen;
			for(int iIndex = 0;iIndex<iLength;iIndex=iIndex+iModlen)
			{
				if(iIndex + iModlen> iLength)
				{
					iSendlen = iLength-iIndex;
				}
				mOutputStream.write(bSend,iIndex,iSendlen);
				sleep(iSleep);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public byte[] read(byte[] bSend) throws IOException {
		byte[] bResult = null;
		send(bSend);

		mreadThread.mReadLen = 0; 
		int iIndex = 0; 
		   
		for(iIndex=0;iIndex<20;iIndex++){
			//System.out.println("iIndex========"+iIndex);
			if(mreadThread.mReadLen>0)
			{
				bResult = new byte[mreadThread.mReadLen];
				for(iIndex=0;iIndex<mreadThread.mReadLen;iIndex++)
					bResult[iIndex] = mreadThread.mReadBuffer[iIndex];
				break;
			}
			sleep(100);
		} 
		return bResult;
	}	
	// 监听服务端
	public void listenAsServer() throws IOException {
		this.mserverSocket = this.mBluetoothAdapter
				.listenUsingRfcommWithServiceRecord(PROTOCOL_SCHEME_RFCOMM,
						UUID.fromString(SPP_UUID));
	}
	// socket接受
	public void accept() throws IOException {
		this.socket = this.mserverSocket.accept();
	}
	// 关闭服务端
	public void shutdownServer() throws IOException {
		if (this.mreadThread != null) {
			this.mreadThread.interrupt();
			this.mreadThread = null;
		}
		if (this.socket != null) {
			this.socket.close();
			this.socket = null;
		}
		if (this.mserverSocket != null) {
			this.mserverSocket.close();
			this.mserverSocket = null;
		}
	}
	// 关闭客户端
	public void shutdownClient() {
		if (this.mreadThread != null) {
			this.mreadThread.interrupt();
			this.mreadThread = null;
		}
		if (this.socket != null) {
			try {
				this.socket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			this.socket = null;
		}
	}
	
	// 判断sockt是否建立连接
	public boolean isConnected() {
		return this.socket != null;
	} 
	
	// 关闭蓝牙
	public void closeBlueTooth() {
		this.mBluetoothAdapter.disable();
	}
 
	public void Open() {
		// 暂无实现
	} 
	
	/**
	 * 配对蓝牙
	 * @param strAddr
	 * @param strPsw
	 * @return boolean
	 */
	public static boolean setPairBluetooth(String strAddr, String strPsw) {
		boolean result = false;
		BluetoothAdapter bluetoothAdapter = BluetoothAdapter
				.getDefaultAdapter();
		bluetoothAdapter.cancelDiscovery();

		if (!bluetoothAdapter.isEnabled()) {
			bluetoothAdapter.enable();
		}

		if (!BluetoothAdapter.checkBluetoothAddress(strAddr)) {
			Log.d("mylog", "devAdd un effient!");
			return false;
		}

		BluetoothDevice remoteDevice = bluetoothAdapter
				.getRemoteDevice(strAddr);

		if (remoteDevice.getBondState() != 12) {
			try {
///				ClassUtils.setPin(remoteDevice.getClass(), remoteDevice, strPsw);
///				ClassUtils.createBond(remoteDevice.getClass(), remoteDevice);
				result = true;
			} catch (Exception e) {
				Log.d("mylog", "setPiN failed!");
				e.printStackTrace();
			}
		} else {
			result = true;
		}
		return result;
	}

	// 线程(读发送的指令InputStream)
	private class readThread extends Thread {
		public byte[] mReadBuffer;
		public int mReadLen;
		private readThread() {
			mReadBuffer = new byte[1024];
			mReadLen = 0;
		}

		public void run() {
			InputStream mmInStream = null;
			try {
				mmInStream = BluetoothManager.this.getServerInputStream();
			} catch (IOException e2) {
				e2.printStackTrace();
			}
			try {
				while (true) {
					int bytes;
					if ((bytes = mmInStream.read(mReadBuffer)) > 0) {
						System.out.println("ReadData:");
						byte[] buf_data = new byte[bytes];
						for (int i = 0; i < bytes; i++) {
							buf_data[i] = mReadBuffer[i];
							System.out.print(" " + buf_data[i]);
						}
						System.out.println("");
						mReadLen = bytes;

					}
				}
			} catch (IOException e) {
				try {
					mmInStream.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		}
	}
	
	public synchronized void sleep(long msec) {
		try {
			wait(msec);
		} catch (InterruptedException e) {
		}
	}
 
}